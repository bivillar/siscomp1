

exec <nome> (2,10,4)
exec <nome> (20,20,4)

for(i=0;i<p->numR;i++){
				printf("v[%d]= %d\n",i,p->raj[i]);
			}
